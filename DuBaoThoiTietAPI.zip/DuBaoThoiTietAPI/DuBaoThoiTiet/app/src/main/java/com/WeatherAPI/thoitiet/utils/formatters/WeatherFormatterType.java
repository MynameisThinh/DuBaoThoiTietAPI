package com.WeatherAPI.thoitiet.utils.formatters;

public enum WeatherFormatterType { NOTIFICATION_DEFAULT, NOTIFICATION_SIMPLE }
