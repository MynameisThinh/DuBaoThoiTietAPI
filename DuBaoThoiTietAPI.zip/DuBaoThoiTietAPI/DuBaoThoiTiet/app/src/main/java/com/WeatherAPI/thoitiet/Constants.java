package com.WeatherAPI.thoitiet;

public class Constants {

public static final String  DEFAULT_CITY = "HoChiMinh";
    public static final String  DEFAULT_LAT = "10.7691";
    public static final String  DEFAULT_LON = "106.6571";
    public static final String DEFAULT_CITY_ID = "1566083";
    public static final int DEFAULT_ZOOM_LEVEL = 7;
}
